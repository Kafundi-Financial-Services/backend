const express = require("express");
const router = express.Router();
const fetch = require("axios");



// connect to your db
const Pool = require("pg").Pool;
const pool = new Pool({
	user: "geophrey",
	host: "localhost",
	database: "mydb",
	password: "thugs123",
	port: 5432,
});

router
	.route("/")
	.post((req, res) => {
		// make the query of the talents you want to send through the email from the database.
		// filter them to ensure they match the desired criteria
		//i decided to just create a variable to simulate the array that will be the result of query from the db.
		const dbresult = [
			{ name: "Vidit Anand", skill: "Full stack", years: 3 },
			{ name: "Nihal Sarin", skill: "Backend specialist", years: 6 },
			{ name: "Vishy Anand", skill: "Frontend", years: 4 },
		]

		//sample query
		// pool.query('SELECT * FROM talent', (error, results) => {
		// 	if (error) {
		// 	  throw error
		// 	}else{
		// 		// console.log(results.rows) // results.rows will be the array that you will use instead of the "dbresult" variable
		
		// 	}
		//   })

		const options = {
			method: "POST",
			url: "https://api.sendinblue.com/v3/smtp/email",
			headers: {
				accept: "application/json",
				"content-type": "application/json",
				"api-key":
					"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", //the api-key from sib
			},
			data: {
				to: [{ email: "mukisageophrey@gmail.com" }], // the list of the reciepients (recruiters). the elements of the array should be object containing an atleast an "email" property.
				params: {
					talents: dbresult // the array from the db
				},
				templateId: 14, //the template id from sendinblue
			},
		};

		fetch
			.request(options)
			.then(function (response) {
				// the response after send the email successfully to the recruiter.
				console.log(response.data);
			})
			.catch(function (error) {
				// incase of an error while send the email to the recruiter
				console.error(error);
			});

	})
	

module.exports = router;
